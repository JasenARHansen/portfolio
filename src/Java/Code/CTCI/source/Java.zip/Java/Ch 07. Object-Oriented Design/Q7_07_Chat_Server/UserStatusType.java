package Q7_07_Chat_Server;

public enum UserStatusType {
	Offline, Away, Idle, Available, Busy
}
