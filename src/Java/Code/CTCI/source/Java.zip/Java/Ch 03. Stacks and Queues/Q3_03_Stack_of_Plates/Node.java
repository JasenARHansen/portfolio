package Q3_03_Stack_of_Plates;

public class Node {
	public Node above;
	public Node below;
	public int value;
	public Node(int value) {
		this.value = value;
	}
}
